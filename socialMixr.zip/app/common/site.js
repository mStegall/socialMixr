$(document).ready(function () {
    $(".collapser").click(function (){
        $(".collapse").collapse("hide");
    });
});